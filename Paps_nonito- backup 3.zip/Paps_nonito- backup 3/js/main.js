    /* ==========================================
       THEME ENGINE TOGGLE
       ========================================== */
    const themeBtn = document.getElementById('themeToggleBtn');
    const themeIcon = document.getElementById('themeIcon');
    themeIcon.textContent = document.documentElement.classList.contains('dark-mode') ? '◐' : '◑';

    themeBtn.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark-mode');
      themeIcon.textContent = isDark ? '◐' : '◑';
      try { localStorage.setItem('portfolio-theme', isDark ? 'dark' : 'light'); } catch {}
    });

    /* ==========================================
       MOBILE MENU TOGGLE
       ========================================== */
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.getElementById('navLinks');

    mobileBtn.addEventListener('click', () => {
      setMenu(!navLinks.classList.contains('open'));
    });

    /* ==========================================
       CASE STUDY DATA & MODAL LOGIC
       ========================================== */
    function openCaseModal(index) {
      const p = caseStudies[index];
      document.getElementById('modalImg').src = p.img;
      document.getElementById('modalTitle').textContent = p.title;
      document.getElementById('modalCategory').textContent = p.category;
      document.getElementById('modalProblem').textContent = p.problem;
      document.getElementById('modalSolution').textContent = p.solution;
      document.getElementById('modalArchitecture').textContent = p.architecture;
      document.getElementById('modalImpact').textContent = p.impact;

      const techContainer = document.getElementById('modalTechStack');
      techContainer.innerHTML = p.tech.map(t => `<span class="tech-tag">${t}</span>`).join('');

      document.getElementById('modalImg').alt = p.title;
      document.getElementById('modalConsiderations').textContent = projectConsiderations[index];
      document.getElementById('caseDetails').hidden = false;
      showModal();
    }

    function closeCaseModal() {
      hideModal();
    }

    function closeCaseModalOnBackdrop(e) {
      if (e.target.id === 'caseModalOverlay') closeCaseModal();
    }

    function filterProjects(category, button) {
      document.querySelectorAll('.filter-btn').forEach(btn => { btn.classList.toggle('active', btn === button); btn.setAttribute('aria-pressed', String(btn === button)); });

      const cards = document.querySelectorAll('.case-card');
      cards.forEach(card => {
        if (category === 'all' || card.dataset.category.split(' ').includes(category)) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    }

    /* ==========================================
       ARCHITECTURE INTERACTIVE NODES
       ========================================== */
    const archDetails = [
      "NODE STATUS: SENSORS & HARDWARE\nLow-power ESP32 microcontroller reading 3-axis accelerometer values at 100Hz with custom solar charging firmware and battery monitoring circuits.",
      "NODE STATUS: LORA MESH GATEWAY\nLong-range, low-bitrate wireless communication node transmitting seismic telemetry up to 15km without reliance on cellular towers.",
      "NODE STATUS: EDGE AI ENGINE\nEdge computing inference pipeline performing real-time signal classification and filtering noise from true seismic anomalies.",
      "NODE STATUS: CLOUD MICROSERVICES\nScalable REST & WebSocket API infrastructure routing critical alerts to emergency first-responders and databases.",
      "NODE STATUS: CLIENT DASHBOARDS\nReal-time Flutter mobile app and web command center displaying interactive map routes and live emergency guidance."
    ];

    function selectArchNode(index) {
      const nodes = document.querySelectorAll('.arch-node');
      nodes.forEach((n, i) => {
        n.setAttribute('aria-pressed', String(i === index));
        if (i === index) n.classList.add('active');
        else n.classList.remove('active');
      });
      document.getElementById('archDetailsPanel').innerText = archDetails[index];
    }

    /* ==========================================
       DEVELOPER CLI TERMINAL ENGINE
       ========================================== */
    const terminalInput = document.getElementById('terminalInput');
    const terminalOutput = document.getElementById('terminalOutput');
    const terminalBody = document.getElementById('terminalBody');

    const commands = {
      help: `Available commands:
  - <span class="text-accent-cyan">whoami</span>    : Print identity & founder profile
  - <span class="text-accent-cyan">skills</span>    : Display core engineering & AI competencies
  - <span class="text-accent-cyan">projects</span>  : List featured engineering case studies
  - <span class="text-accent-cyan">stats</span>     : Print quantifiable metrics & impact
  - <span class="text-accent-cyan">contact</span>   : Output phone, email, and location details
  - <span class="text-accent-cyan">matrix</span>    : Display high-tech terminal telemetry graphics
  - <span class="text-accent-cyan">clear</span>     : Clear terminal buffer screen`,

      whoami: `NONITO L. MOLIJON JR.
--------------------------------------------------
Role: Computer Engineer, AI Builder & Technopreneur
Founder: CEO & Founder @ Apex of Champions OPC
Focus: Intelligent Systems, Hardware-Software Integration, Computer Vision, & Research Analytics.`,

      skills: `CORE COMPETENCIES MATRIX:
--------------------------------------------------
[+] Software Engineering: Full-Stack Web, Flutter Mobile, REST APIs, Microservices
[+] Artificial Intelligence: Computer Vision, OpenCV, PyTorch ML, AI Automations
[+] Hardware & IoT: ESP32 Firmware, LoRa Wireless Mesh, Sensors, Solar Power Circuits
[+] Technopreneurship: Venture Strategy, Research Consulting, Product Development`,

      projects: `FEATURED ENGINEERING CASE STUDIES:
--------------------------------------------------
1. AI-LERT System        : Solar IoT Earthquake Detection (ESP32 / LoRa / AI)
2. AI Image Classifier   : Computer Vision Synthetic Media Detector (OpenCV)
3. Offline ID Package    : High-Speed Desktop Image Processing Suite
4. R&N Research Engine   : Data Analytics & AI Research Platform`,

      stats: `QUANTIFIABLE METRICS:
--------------------------------------------------
- Team Members Collaborated With : 10+
- Years Building Tech Solutions  : 4+
- Projects Delivered             : 50+
- Enterprise Systems Architected : 10+
- Clients & Organizations Served  : 500+`,

      contact: `CONTACT TELEMETRY:
--------------------------------------------------
- Mobile/WhatsApp : +63 955 398 3149
- Direct Email    : nonitolabitoriamolijon@gmail.com
- Location        : Sampao, Isulan, Sultan Kudarat, Philippines 📍
- Company Portal  : https://apex-of-champions.vercel.app`,

      matrix: `[SYSTEM DIAGNOSTIC GRAPH]
 100% | * * * * * * * * * * * * * * * * * [OPTIMAL]
  75% |   *   *   *   *   *   *   *   *  [STABLE]
  50% |     *   *   *   *   *   *   *    [LOW LATENCY]
  00% +----------------------------------
      01  02  03  04  05  06  07  08`
    };

    terminalInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const cmd = terminalInput.value.trim().toLowerCase();
        const safeCmd = cmd.replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
        terminalInput.value = '';

        if (cmd === 'clear') {
          terminalOutput.innerHTML = '';
          return;
        }

        const promptLine = `\n<span class="prompt-symbol">nonito@nlm-lab:~$</span> ${safeCmd}\n`;
        let response = '';

        if (Object.hasOwn(commands, cmd)) {
          response = commands[cmd];
        } else if (cmd === '') {
          response = '';
        } else {
          response = `Command not found: '<span style="color: #ff5f56;">${safeCmd}</span>'. Type '<span class="text-accent-cyan">help</span>' for available commands.`;
        }

        terminalOutput.innerHTML += promptLine + response;
        terminalBody.scrollTop = terminalBody.scrollHeight;
      }
    });


// Modal lifecycle shared by case studies and experience previews.
const projectConsiderations = [
  'Key constraints: energy availability, intermittent connectivity, and the distinction between noisy sensor readings and useful alerts.',
  'Key constraints: image compression, varied image sources, and interpreting confidence scores without treating them as certainty.',
  'Key constraints: portrait variation, consistent crop geometry, and maintaining a fully offline processing workflow.',
  'Key constraints: data quality, appropriate statistical model selection, and review of AI-assisted research outputs.'
];
const modal = document.getElementById('caseModalOverlay');
let modalTrigger = null;
function showModal() {
  modalTrigger = document.activeElement;
  modal.classList.add('active');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  document.querySelectorAll('body > :not(script):not(main), main > :not(#caseModalOverlay)').forEach(el => el.inert = true);
  modal.querySelector('.case-modal-container').scrollTop = 0;
  modal.querySelector('.modal-close-btn').focus();
}
function hideModal() {
  if (!modal.classList.contains('active')) return;
  modal.classList.remove('active');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  document.querySelectorAll('[inert]').forEach(el => el.inert = false);
  modalTrigger?.focus();
}
function openExpLightbox(src, title, description) {
  document.getElementById('modalImg').src = src;
  document.getElementById('modalImg').alt = title;
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalCategory').textContent = description;
  document.getElementById('caseDetails').hidden = true;
  showModal();
}
function setMenu(open) {
  navLinks.classList.toggle('open', open);
  mobileBtn.setAttribute('aria-expanded', String(open));
  mobileBtn.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
}
navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('click', e => { if (!e.target.closest('.navbar')) setMenu(false); });
matchMedia('(min-width: 769px)').addEventListener('change', e => { if (e.matches) setMenu(false); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    hideModal();
    if (navLinks.classList.contains('open')) { setMenu(false); mobileBtn.focus(); }
  }
  if (e.key === 'Tab' && modal.classList.contains('active')) {
    const items = [...modal.querySelectorAll('button, a[href], [tabindex="0"]')].filter(el => el.getClientRects().length);
    const first=items[0], last=items.at(-1);
    if(e.shiftKey && document.activeElement===first){e.preventDefault();last.focus();}
    else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus();}
  }
});
document.querySelectorAll('.case-card, .exp-card[onclick], .arch-node').forEach(el => {
  el.tabIndex=0; el.setAttribute('role','button');
  el.setAttribute('aria-label', el.querySelector('h3, .arch-node-title')?.textContent.trim() || 'Explore project');
  if(el.matches('.case-card, .exp-card')) el.setAttribute('aria-haspopup','dialog');
  if(el.matches('.arch-node')) el.setAttribute('aria-pressed',String(el.classList.contains('active')));
  el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click();}});
});
document.querySelectorAll('.filter-btn').forEach(el=>el.setAttribute('aria-pressed',String(el.classList.contains('active'))));
document.querySelectorAll('[data-command]').forEach(el=>el.addEventListener('click',()=>{
  terminalInput.value=el.dataset.command;
  terminalInput.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  terminalInput.focus({preventScroll:true});
}));
const navObserver = new IntersectionObserver(entries => {
  for (const entry of entries) if(entry.isIntersecting) {
    document.querySelectorAll('.nav-link').forEach(link=>{
      const active=link.hash==='#'+entry.target.id;
      link.classList.toggle('active',active);
      if(active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
    });
  }
},{rootMargin:'-15% 0px -55% 0px'});
document.querySelectorAll('main > section').forEach(section=>navObserver.observe(section));
