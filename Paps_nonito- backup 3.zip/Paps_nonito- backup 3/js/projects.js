    const caseStudies = [
      {
        title: "AI-LERT: Solar-Powered IoT Seismic Detection System",
        category: "IoT & Artificial Intelligence",
        img: "assets/ailert_cover.webp",
        problem: "Traditional earthquake monitoring units require heavy power infrastructure and lack real-time local mesh communication during severe disaster power outages.",
        solution: "Engineered an autonomous, solar-powered IoT seismic detection node utilizing ESP32 microcontrollers, LoRa long-range wireless mesh communication, and AI-driven decision algorithms for emergency navigation.",
        architecture: "Sensors (3-Axis Accelerometer) ➔ Local ESP32 Node ➔ LoRa Mesh Gateway ➔ Cloud AI Decision Pipeline ➔ Flutter Emergency Navigation App",
        tech: ["ESP32 Firmware", "LoRa Mesh Protocol", "Flutter Mobile App", "AI Decision Engine", "Solar Telemetry"],
        impact: "Provides off-grid seismic warning capability with 99.4% telemetry uptime during simulated power blackouts."
      },
      {
        title: "AI-Generated Image Classifier Framework",
        category: "Computer Vision & Machine Learning",
        img: "assets/classifier_cover.webp",
        problem: "Proliferation of deepfake and synthetic AI images makes distinguishing genuine visual evidence from generated media increasingly challenging.",
        solution: "Built a computer vision analysis framework leveraging OpenCV features, neural network artifact inspection, and machine learning confidence scoring.",
        architecture: "Input Image ➔ Feature Extraction Layer (OpenCV) ➔ Neural Artifact Scanner ➔ Statistical Confidence Model ➔ Real-time HUD Visualizer",
        tech: ["Python", "OpenCV", "Machine Learning", "PyTorch", "Synthetic Media Detection"],
        impact: "Achieved 96.2% accuracy in classifying synthetic AI-generated images across diverse lighting and compression artifacts."
      },
      {
        title: "Offline ID Package Processing System",
        category: "Desktop Automation & Image Processing",
        img: "assets/idsystem_cover.webp",
        problem: "Manual background removal, face alignment, and multi-size print sheet layout generation cause huge bottlenecks in high-volume portrait studios.",
        solution: "Developed an offline desktop application that automates portrait background isolation, standard ID size cropping, and high-efficiency print sheet rendering.",
        architecture: "Raw Photo Import ➔ Automatic Background Removal ➔ Face Landmark Cropping ➔ Print Layout Generator ➔ Direct Printer Spooler",
        tech: ["Desktop GUI Engine", "Image Processing Pipelines", "Batch Processing", "Print Spooler Integration"],
        impact: "Reduced per-photo processing time from 4 minutes to under 8 seconds per client."
      },
      {
        title: "R&N Research Analytics & AI Engine",
        category: "Data Science & Research Consultancy",
        img: "assets/researchengine_cover.webp",
        problem: "Academic research and statistical analytics workflows require seamless integration between data cleaning, statistical modeling, and AI report synthesis.",
        solution: "Created an end-to-end research analytics engine incorporating statistical modeling modules with AI-assisted report generation capabilities.",
        architecture: "Raw Dataset ➔ Statistical Model Suite (Bayesian/Regression) ➔ AI Insight Generator ➔ Publication-ready Visual Dashboard",
        tech: ["Data Science", "Python Analytics", "AI Assistance", "Statistical Modeling", "Custom Dashboards"],
        impact: "Empowered over 500 research clients with accelerated statistical modeling and automated data insights."
      }
    ];

