/* Decorative motion is bounded, optional, and suspended outside the hero. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const canvas = document.getElementById('particleCanvas');
  const ctx = canvas.getContext('2d');
  let points=[], width=0, height=0, frame=0, visible=true, previous=0;
  const resize = () => {
    width=innerWidth; height=document.getElementById('home').offsetHeight;
    const ratio=Math.min(devicePixelRatio || 1,1.5);
    canvas.width=width*ratio; canvas.height=height*ratio;
    canvas.style.height=height+'px'; ctx?.setTransform(ratio,0,0,ratio,0,0);
    points=Array.from({length:Math.min(48,Math.floor(width/25))},()=>({x:Math.random()*width,y:Math.random()*height,vx:(Math.random()-.5)*.2,vy:(Math.random()-.5)*.2}));
    draw(false);
  };
  function draw(move) {
    if(!ctx)return;
    ctx.clearRect(0,0,width,height);
    const dark=document.documentElement.classList.contains('dark-mode');
    ctx.fillStyle=dark?'#7ce8dd':'#0284c7';
    points.forEach((p,i)=>{
      if(move){p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>width)p.vx*=-1;if(p.y<0||p.y>height)p.vy*=-1;}
      ctx.beginPath();ctx.arc(p.x,p.y,1.5,0,Math.PI*2);ctx.fill();
      points.slice(i+1).forEach(q=>{const d=Math.hypot(p.x-q.x,p.y-q.y);if(d<160){ctx.strokeStyle=dark?`rgba(124,232,221,${(1-d/160)*.3})`:`rgba(2,132,199,${(1-d/160)*.3})`;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke();}});
    });
  }
  function tick(time){if(time-previous>32){draw(true);previous=time;}frame=requestAnimationFrame(tick);}
  function sync(){cancelAnimationFrame(frame);if(!reduced.matches&&!document.hidden&&visible&&ctx)frame=requestAnimationFrame(tick);else draw(false);}
  resize(); sync();
  const roles=['CEO & Founder @ Apex of Champions OPC','AI & Computer Vision Engineer','Embedded Systems (ESP32 & LoRa) Specialist','Lead Statistical Research Consultant','Full-Stack Intelligent Systems Architect'];
  let role=0;
  setInterval(()=>{if(!reduced.matches&&!document.hidden&&visible){document.getElementById('rotatorText').textContent=roles[++role%roles.length];}},5000);
  window.addEventListener('resize',resize,{passive:true});
  document.addEventListener('visibilitychange',sync); reduced.addEventListener('change',sync);
  document.getElementById('themeToggleBtn').addEventListener('click',()=>draw(false));
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();}).observe(document.getElementById('home'));
  const reveal=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.replace('reveal-pending','reveal-visible');reveal.unobserve(e.target);}}),{threshold:.08});
  document.querySelectorAll('section:not(#home) .section-header, .philosophy-card, .skill-card, .exp-card').forEach(el=>{el.classList.add('reveal-pending');reveal.observe(el);});
  const portrait=document.getElementById('portraitCard');
  const spotlight=document.getElementById('cursorSpotlight');
  if(matchMedia('(pointer:fine)').matches){
    document.addEventListener('pointermove',e=>{if(reduced.matches)return;spotlight.style.left=e.clientX+'px';spotlight.style.top=e.clientY+'px';},{passive:true});
    portrait.addEventListener('pointermove',e=>{if(reduced.matches)return;const r=portrait.getBoundingClientRect();portrait.style.transform=`rotateY(${((e.clientX-r.left)/r.width-.5)*5}deg) rotateX(${((e.clientY-r.top)/r.height-.5)*-5}deg)`;});
    portrait.addEventListener('pointerleave',()=>portrait.style.transform='');
  }
})();
